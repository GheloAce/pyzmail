pyzmail library
==============

pyzmail: Python eazy mail library
Copyright: Alain Spineux <alain.spineux@gmail.com>
License: LGPL
Homepage: http://www.magiksys.net/pyzmail/

Overview
--------

pyzmail is a high level mail library for Python. It provides functions and
classes that help to read, compose and send emails. pyzmail exists because
their is no reasons that handling mails with Python would be more difficult
than with popular mail clients like Outlook or Thunderbird. pyzmail hide the
difficulties of the MIME structure and MIME encoding/decoding. It also hide
the problem of the internationalized header encoding/decoding.


